#######################################################################
#Import Modules and or Scripts
import xbmc, xbmcaddon, xbmcgui, xbmcplugin
import os
#######################################################################

#######################################################################
#You can change the colors of your wizard text here. 
#Please do not edit # or change COLOR2 or it will break all the colors 
# in the entire wizard!
# For a complete list of colors available please visit
# http://forum.kodi.tv/showthread.php?tid=210837
COLOR               = '[COLOR red][B]'
COLOR1              = '[COLOR snow][B]'
COLOR2              = '[/B][/COLOR]'
COLOR3              = '[COLOR crimson][B]'
COLOR4              = '[COLOR springgreen][B]'
#######################################################################
#Editable Global Variables and Notification Settings
#######################################################################
#This should MATCH your plugin name (folder name) exactly.
AddonID             = 'plugin.program.tksappsbasicwizard'
#######################################################################
#This is the URL to the directory where your .txt and .xml files are
#located on your host.
#IMPORTANT DO NOT ADD THE / AT THE END OF YOUR URL OR YOUR WIZARD
#WILL NOT WORK. IT HAS BEEN CODED TO ADD THE / ITSELF!!!!!!!!!!!!!!!!
#CORRECT WORKING EXAMPLE: 'http://tksapps.com/files/docs'
#BAD NON WORKING EXAMPLE: 'http://tksapps.com/files/docs/'
URL                 = 'http://tksapps.com/files/docs/'
#######################################################################
#Set your Title here example: 'Tk's Applications for Kodi: Wizard'
ADDONTITLE          = 'TK\'s Applications for Kodi: Basic Wizard'
#######################################################################
#You can change this to match your wizard name if you would like. 
#Please be sure to leave a space after the same before the ' at the end.
GROUP_NAME          = 'TK\'s Applications for Kodi '
#######################################################################
#This is the "folder" that your files are located in on your host. So if
#your url is http://yoururlhere.com/tksapps/ then the PATH is tksapps.
PATH                = "files"
#######################################################################
#DO NOT EDIT THIS LINE PLEASE!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
BASEURL             = URL + '/'
#######################################################################                                                           
#Adult Wizard text file
ADULTFILE           = BASEURL + 'adult.txt'
#######################################################################
#Adult Wizard text file for Kodi 17
ADULTFILE17         = BASEURL + 'adult17.txt'
#######################################################################
#Wizard text file
WIZARDFILE          = BASEURL + 'wizard.txt'
#######################################################################
#Wizard text file for Kodi 17
WIZARDFILE17        = BASEURL + 'wizard17.txt'
#######################################################################
#Menu Names are controlled here
ADULT               = 'Adults Builds Menu'
ADULT17             = 'Adults Builds Menu for Kodi 17'
BUILD               = 'Builds Menu'
BUILD17             = 'Builds Menu for Kodi 17'
#######################################################################
#Please do not change the the code for ART as this will affect all images!
ART                 = xbmc.translatePath(os.path.join('special://home/addons/' + AddonID, 'resources/art/'))
#######################################################################

#######################################################################
#Image ICON's are set below
ADULT_ICON          = ART + 'adult.png'
ADULT17_ICON        = ART + 'adult17.png'
BUILDS_ICON			= ART + 'builds.png'
BUILDS17_ICON       = ART + 'builds17.png'
FANART              = xbmc.translatePath(os.path.join('special://home/addons/' + AddonID , 'fanart.jpg'))
#######################################################################

#######################################################################
#Global Variables
#Do Not Edit These Variables or any others in this wizard!
#######################################################################
ADDON               = xbmcaddon.Addon(id=AddonID)
HOME                = xbmc.translatePath('special://home/')
USERDATA            = os.path.join(HOME,      'userdata')
ADDON_ID            = xbmcaddon.Addon().getAddonInfo('id')
ADDONDATA           = os.path.join(USERDATA,  'addon_data', ADDON_ID)
DIALOG              = xbmcgui.Dialog()
dp                  = xbmcgui.DialogProgress()
USER_AGENT          = 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3'
#######################################################################