#######################################################################
#Import Modules Section
import xbmc, xbmcgui, xbmcplugin
import os
import sys
import urllib
import urllib2
from urllib2 import urlopen
import extract
import downloader
import re
import time
import glo_var
#######################################################################

####################################################################################
#Variables used from glo_var.py file
#Do Not Edit These Variables or any others in this wizard!
ADDON               = glo_var.ADDON
ADDONDATA           = glo_var.ADDONDATA
ADDONTITLE          = glo_var.ADDONTITLE
ART                 = glo_var.ART
cr                  = glo_var.COLOR
cr1                 = glo_var.COLOR1
cr2                 = glo_var.COLOR2
cr3                 = glo_var.COLOR3
cr4                 = glo_var.COLOR4
dp                  = glo_var.dp
DIALOG              = glo_var.DIALOG
gn                  = glo_var.GROUP_NAME
####################################################################################

####################################################################################
#The code in this addDir variable was written for when you wish upon click to open
#a new window.
def addDir(name,url,mode,iconimage,fanart,description):
        u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)+"&iconimage="+urllib.quote_plus(iconimage)+"&fanart="+urllib.quote_plus(fanart)+"&description="+urllib.quote_plus(description)
        ok=True
        liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
        liz.setInfo( type="Video", infoLabels={ "Title": name, "Plot": description } )
        liz.setProperty( "Fanart_Image", fanart )
        if mode==90 : ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=False)
        else: ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=True)
        return ok
####################################################################################

####################################################################################
#The code in this addDir2 variable was written for when you just wish to open the 
#variable itself, like a pop-up notification window.
def addDir2(name,url,mode,iconimage,fanart,description):
        u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)+"&iconimage="+urllib.quote_plus(iconimage)+"&fanart="+urllib.quote_plus(fanart)+"&description="+urllib.quote_plus(description)
        ok=True
        liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
        liz.setInfo( type="Video", infoLabels={ "Title": name, "Plot": description } )
        liz.setProperty( "Fanart_Image", fanart )
        if mode==90 : ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=True)
        else: ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=False)
        return ok        
####################################################################################

#################################################################################### 
#Calling the ebi process within XBMC
def ebi(proc):
    xbmc.executebuiltin(proc)
#################################################################################### 

#################################################################################### 
#Get Setting, this is used to pull information from the setting.xml file itself
def getS(name):
    try: return ADDON.getSetting(name)
    except: return False

def get_setting(name): _log("get_setting name='"+name+"'"); dev=__settings__.getSetting(name); _log("get_setting ->'"+str(dev)+"'"); return dev    
#################################################################################### 

####################################################################################  
#Kill XBMC Commands - Working version on all OS      
def killxbmc(over=None):
    if over: choice = 1
    else: choice = DIALOG.yesno(cr+'Force Close Kodi'+cr2, cr1+'You should Force Close Kodi for your changes to take effect.'+cr2, cr1+'Would you like to continue?'+cr2, nolabel=cr1+'Cancel'+cr2,yeslabel=cr+'Force Close Kodi'+cr2)
    if choice == 1:
        log("Force Closing Kodi: Platform[%s]" % str(platform()))
        os._exit(1)
####################################################################################

def log(log):
    xbmc.log("[%s]: %s" % (cr+ADDONTITLE+cr2, log))
    if not os.path.exists(ADDONDATA): os.makedirs(ADDONDATA)

def loga(msg, level=xbmc.LOGDEBUG):
    if getS('addon_debug') == 'true' and level == xbmc.LOGDEBUG:
        level = xbmc.LOGNOTICE
    try:
        if isinstance(msg, unicode):
            msg = '%s' % (msg.encode('utf-8'))
        xbmc.log('%s: %s' % (ADDONTITLE, msg), level)
    except Exception as e:
        try: xbmc.log('Logging Failure: %s' % (e), level)
        except: pass
    if not os.path.exists(ADDONDATA): os.makedirs(ADDONDATA)
    if not os.path.exists(WIZLOG): f = open(WIZLOG, 'w'); f.close()
    with open(WIZLOG, 'a') as f:
        line = "[%s %s] %s" % (datetime.now().date(), str(datetime.now().time())[:8], msg)
        f.write(line.rstrip('\r\n')+'\n') 

####################################################################################  
#I don't believe I need to explain this one :)  
def OPEN_URL(url):
    req = urllib2.Request(url)
    req.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3')
    response = urllib2.urlopen(req)
    link=response.read()
    response.close()
    return link
####################################################################################

####################################################################################
#Defining the platforms so that other code works correctly.
def platform():
    if xbmc.getCondVisibility('system.platform.android'):   return 'android'
    elif xbmc.getCondVisibility('system.platform.linux'):   return 'linux'
    elif xbmc.getCondVisibility('system.platform.windows'): return 'windows'
    elif xbmc.getCondVisibility('system.platform.osx'):     return 'osx'
    elif xbmc.getCondVisibility('system.platform.atv2'):    return 'atv2'
    elif xbmc.getCondVisibility('system.platform.ios'):     return 'ios'
####################################################################################

#################################################################################### 
#Wizard variables   
def Wizard(name,url,description):
    path = xbmc.translatePath(os.path.join('special://home/addons','packages'))
    dp = xbmcgui.DialogProgress()
    dp.create(cr+gn+cr2+"[COLOR red][B] and TK's: WIZARD[/B][/COLOR]","[COLOR snow][B]The selected build is now downloading.[/B][/COLOR] ",'', '[COLOR snow][B]Please be patient[/B][/COLOR]')
    lib=os.path.join(path, name+'.zip')
    try:
       os.remove(lib)
    except:
       pass
    downloader.download(url, lib, dp)
    addonfolder = xbmc.translatePath(os.path.join('special://','home'))
    time.sleep(2)
    dp.update(0,"", "[COLOR snow][B]Extracting[/B][/COLOR]"+cr+gn+cr2+"[COLOR snow][B]Build now, Please Wait[/B][/COLOR]")
    print '======================================='
    print addonfolder
    print '======================================='
    extract.all(lib,addonfolder,dp)
    DIALOG = xbmcgui.Dialog()
    DIALOG.ok("[COLOR red][B]DOWNLOAD COMPLETE![/B][/COLOR]", '[COLOR snow][B]To ensure all changes are saved you must now close Kodi[/B][/COLOR]', '[COLOR snow][B]Android users can click okay and it WILL force close itself.[/B][/COLOR]')
    killxbmc()

def Wizard_Adult(name,url,description):
    path = xbmc.translatePath(os.path.join('special://home/addons','packages'))
    dp = xbmcgui.DialogProgress()
    dp.create(cr+gn+cr2+"[COLOR red][B] and TK's: WIZARD[/B][/COLOR]","[COLOR snow][B]The selected build is now downloading.[/B][/COLOR] ",'', '[COLOR snow][B]Please be patient[/B][/COLOR]')
    lib=os.path.join(path, name+'.zip')
    try:
       os.remove(lib)
    except:
       pass
    downloader.download(url, lib, dp)
    addonfolder = xbmc.translatePath(os.path.join('special://','home'))
    time.sleep(2)
    dp.update(0,"", cr1+"Extracting"+cr2+ cr+gn+ cr2+ cr3+" ADULT"+cr2+ cr+"Build"+cr2+ cr1+ "now, Please Wait"+cr2)
    print '======================================='
    print addonfolder
    print '======================================='
    extract.all(lib,addonfolder,dp)
    DIALOG = xbmcgui.Dialog()
    DIALOG.ok(cr+"DOWNLOAD COMPLETE!"+cr2, cr1+'To ensure all changes are saved you must now close Kodi'+cr2, cr1+'Android users can click okay and it WILL force close itself.'+cr2)
    killxbmc()

def workingURL(url):
    if url == 'http://': return False
    try: 
        req = urllib2.Request(url)
        req.add_header('User-Agent', USER_AGENT)
        response = urllib2.urlopen(req)
        response.close()
    except Exception, e:
        return e
    return True        
####################################################################################