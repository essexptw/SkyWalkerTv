####################################################################################
#Importing modules and scripts needed to run
import xbmc, xbmcaddon, xbmcplugin,sys
import urllib
import re
import base_info
import glo_var
####################################################################################

####################################################################################           
#Variables used from glo_var.py file
#Do Not Edit These Variables or any others in this wizard!
AddonID        = glo_var.AddonID
ADDON          = xbmcaddon.Addon(id=AddonID)
ADULT          = base_info.getS('adult')
ADULT17        = base_info.getS('adult17')
adult          = glo_var.ADULT
adult17        = glo_var.ADULT17
ADULTFILE      = glo_var.ADULTFILE
ADULTFILE17    = glo_var.ADULTFILE17
ARTA           = glo_var.ADULT_ICON
ARTA17         = glo_var.ADULT17_ICON
ARTBU          = glo_var.BUILDS_ICON
ARTBU17        = glo_var.BUILDS17_ICON
build          = glo_var.BUILD
build17        = glo_var.BUILD17
BUILDS17       = base_info.getS('builds17')
cr             = glo_var.COLOR
cr1            = glo_var.COLOR1
cr2            = glo_var.COLOR2
cr3            = glo_var.COLOR3
cr4            = glo_var.COLOR4
DIR            = base_info.addDir
DIR2           = base_info.addDir2
FANART         = glo_var.FANART
gn             = glo_var.GROUP_NAME
OPEN           = base_info.OPEN_URL
WIZARDFILE     = glo_var.WIZARDFILE
WIZARDFILE17   = glo_var.WIZARDFILE17
####################################################################################

####################################################################################
def CATEGORIES():
    DIR(cr+gn+cr2+cr1+build+cr2,'url','builds',ARTBU,FANART,'')
    if BUILDS17 == 'true': DIR(cr+gn+cr2+cr1+build17+cr2,'url','builds17',ARTBU17,FANART,'')              
    xbmc.executebuiltin('Container.SetViewMode(50)') 
####################################################################################

###################################################################################
#Kodi 16 Jarvis Adult Builds Menu
def Adult_Menu():  
    link = OPEN(ADULTFILE).replace('\n','').replace('\r','')
    match = re.compile('name="(.+?)".+?rl="(.+?)".+?mg="(.+?)".+?anart="(.+?)".+?escription="(.+?)"').findall(link)
    for name,url,image,fanart,description in match:
        DIR2(name,url,'adultwiz',image,fanart,description)
        xbmc.executebuiltin('Container.SetViewMode(50)')
####################################################################################   

###################################################################################
#Kodi 16 Jarvis Builds Menu
def Builds_Menu():
    if ADULT == 'true': DIR(cr+gn+cr2+cr1+adult+cr2,'url','adult',ARTA,FANART,'')  
    link = OPEN(WIZARDFILE).replace('\n','').replace('\r','')
    match = re.compile('name="(.+?)".+?rl="(.+?)".+?mg="(.+?)".+?anart="(.+?)".+?escription="(.+?)"').findall(link)
    for name,url,iconimage,fanart,description in match:
        DIR2(name,url,'install',iconimage,fanart,description)
        xbmc.executebuiltin('Container.SetViewMode(50)')        
####################################################################################  

###################################################################################
#Kodi 17 Krypton Adult Builds Menu
def Adult_Menu17():  
    link = OPEN(ADULTFILE17).replace('\n','').replace('\r','')
    match = re.compile('name="(.+?)".+?rl="(.+?)".+?mg="(.+?)".+?anart="(.+?)".+?escription="(.+?)"').findall(link)
    for name,url,image,fanart,description in match:
        DIR2(name,url,'adultwiz',image,fanart,description)
        xbmc.executebuiltin('Container.SetViewMode(50)')
####################################################################################   

###################################################################################
#Kodi 17 Krypton Builds Menu
def Builds_Menu17():
    if ADULT17 == 'true': DIR(cr+gn+cr2+cr1+adult+cr2,'url','adult17',ARTA17,FANART,'')  
    link = OPEN(WIZARDFILE17).replace('\n','').replace('\r','')
    match = re.compile('name="(.+?)".+?rl="(.+?)".+?mg="(.+?)".+?anart="(.+?)".+?escription="(.+?)"').findall(link)
    for name,url,iconimage,fanart,description in match:
        DIR2(name,url,'install',iconimage,fanart,description)
        xbmc.executebuiltin('Container.SetViewMode(50)')        
####################################################################################  

####################################################################################
#Define Paramaters           
def get_params():
    param=[]
    paramstring=sys.argv[2]
    if len(paramstring)>=2:
        params=sys.argv[2]
        cleanedparams=params.replace('?','')
        if (params[len(params)-1]=='/'):
            params=params[0:len(params)-2]
        pairsofparams=cleanedparams.split('&')
        param={}
        for i in range(len(pairsofparams)):
            splitparams={}
            splitparams=pairsofparams[i].split('=')
            if (len(splitparams))==2:
                param[splitparams[0]]=splitparams[1]
        return param

params=get_params()
url         = None
name        = None
mode        = None
iconimage   = None
fanart      = None
description = None
try:     mode=urllib.unquote_plus(params["mode"])
except:  pass
try:     name=urllib.unquote_plus(params["name"])
except:  pass
try:     url=urllib.unquote_plus(params["url"])
except:  pass
try:     iconimage=urllib.unquote_plus(params["iconimage"])
except:  pass
try:     fanart=urllib.unquote_plus(params["fanart"])
except:  pass
try:     description=urllib.unquote_plus(params["description"])
except:  pass
#######################################################################

#######################################################################
# Defining the set view of the wizard
def setView(content, viewType):
    if content:
        xbmcplugin.setContent(int(sys.argv[1]), content)
    if base_info.getS('auto-view')=='true':
        base_info.ebi("Container.SetViewMode(%s)" % base_info.getS(viewType) )
#######################################################################

#######################################################################
# Below we are creating the different modes        
if mode==None               : CATEGORIES()
elif mode=='adult'          : Adult_Menu()
elif mode=='adult17'        : Adult_Menu17()
elif mode=='adultwiz'       : base_info.Wizard_Adult(name,url,description)
elif mode=='builds'         : Builds_Menu()
elif mode=='builds17'       : Builds_Menu17()
elif mode=='install'        : base_info.Wizard(name,url,description)
#######################################################################

#######################################################################
#End of Directory
xbmcplugin.endOfDirectory(int(sys.argv[1]))
#######################################################################